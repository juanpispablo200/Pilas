/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pilas;

import java.util.Date;

/**
 *
 * @author Juan Pablo
 */
public class PaginaWeb {
    public String nombre;
    public String ruta;
    public Date horaVisita;
    public byte icono;
    public Date fechaCierre;
    public String dipositivos;

    public PaginaWeb(String nombre, String ruta, Date horaVisita, Date fechaCierre, String dipositivos, String dispositivo) {
        this.nombre = nombre;
        this.ruta = ruta;
        this.horaVisita = horaVisita;
        this.icono = icono;
        this.fechaCierre = fechaCierre;
        this.dipositivos = dipositivos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public Date getHoraVisita() {
        return horaVisita;
    }

    public void setHoraVisita(Date horaVisita) {
        this.horaVisita = horaVisita;
    }

    public byte getIcono() {
        return icono;
    }

    public void setIcono(byte icono) {
        this.icono = icono;
    }

    public Date getFechaCierre() {
        return fechaCierre;
    }

    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    public String getDipositivos() {
        return dipositivos;
    }

    public void setDipositivos(String dipositivos) {
        this.dipositivos = dipositivos;
    }

    @Override
    public String toString() {
        return "PaginaWeb{" + "nombre=" + nombre + ", ruta=" + ruta + ", horaVisita=" + horaVisita + ", icono=" + icono + ", fechaCierre=" + fechaCierre + ", dipositivos=" + dipositivos + '}';
    }
    
    
}
